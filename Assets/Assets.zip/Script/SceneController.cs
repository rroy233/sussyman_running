using Google.Protobuf;
using Net.Proto;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneController : MonoBehaviour
{
    public static SceneController Instance;

    [SerializeField] private bool IsMenu=false;
    [SerializeField] private GameObject SpawnCherryPrefab;
    [SerializeField] private Text LevelInfoText;
    [SerializeField] private Text DelayInfoText;

    private string LevelName;
    private int CherryCntNeedChange = -1;
    private static Queue<ItemSpawnNotify> itemSpawnQueue;


    // Start is called before the first frame update
    void Start()
    {
        Instance = this;

        //����·��
        Network._Instance.AddHandleFunc(CmdID.CmdIDSceneDataResp, HandleLevelDataResp);
        if (!IsMenu)
        {
            itemSpawnQueue = new Queue<ItemSpawnNotify>();
            Network._Instance.AddHandleFunc(CmdID.CmdIDItemSpawnNotify, HandleSpawn);

            //������Ʒ��������֪ͨ
            Network._Instance.AddHandleFunc(CmdID.CmdIDItemPickedNumUpdate, handleItemPickedNumUpdate);
        }
        Network._Instance.AddHandleFunc(CmdID.CmdIDSessionEndNotify, HandleSessionEnd);

        //��ȡ�ؿ���Ϣ
        GetLevelData();
    }

    // Update is called once per frame
    void Update()
    {
        //���ǲ˵�����ֱ���ѳ�
        if (IsMenu)
        {
            return;
        }

        //������Ʒ
        if (itemSpawnQueue.Count > 0)
        {
            var pkg = itemSpawnQueue.Dequeue();
            for (int i = 0; i < pkg.Count; i++)
            {
                switch (pkg.List[i].PrefabName)
                {
                    case "Cherry":
                        var obj = Instantiate(SpawnCherryPrefab, new Vector3((float)pkg.List[i].Position.X, (float)pkg.List[i].Position.Y, 0f), Quaternion.identity);
                        obj.name = pkg.List[i].ItemName;
                        break;
                    default:
                        Debug.Log("PrefabName�޷�ʶ��:"+ pkg.List[i].PrefabName);
                        break;
                }

            }
        }

        //����UI
        LevelInfoText.text = LevelName;

        //����cherry count
        if (CherryCntNeedChange != -1 && GameObject.Find("Player")!=null)
        {
            GameObject.Find("Player").GetComponent<ItemCollecter>().EditCherryCnt(CherryCntNeedChange);
            CherryCntNeedChange = -1;
        }
    }

    private void FixedUpdate()
    {
        if (!IsMenu)
        { DelayInfoText.text = Network._Instance.GetDelay() + "ms"; }
    }

    private void HandleLevelDataResp(CmdID cmdID, byte[] msg)
    {
        var pkg = LevelDataResp.Parser.ParseFrom(msg);
        LevelName = pkg.LevelName;
        CherryCntNeedChange = pkg.CherryCount;
    }

    private void handleItemPickedNumUpdate(CmdID cmdID, byte[] msg)
    {
        var pkg = ItemPickedNumUpdate.Parser.ParseFrom(msg);

        Debug.Log("ʰȡ����������->"+pkg.CherryCount.ToString());

        CherryCntNeedChange = pkg.CherryCount;
    }

    private void GetLevelData()
    {
        var pkg = new LevelDataReq();
        pkg.SceneID = SceneManager.GetActiveScene().buildIndex;

        Network._Instance.PackAndSend(CmdID.CmdIDSceneDataReq,pkg.ToByteArray());
    }

    public void HandleSpawn(CmdID cmdID, byte[] msg)
    {
        ItemSpawnNotify pkg = ItemSpawnNotify.Parser.ParseFrom(msg);
        itemSpawnQueue.Enqueue(pkg);
    }

    public void HandleSessionEnd(CmdID cmdID, byte[] data)
    {
        SceneManager.LoadScene(0);
        var nc = GameObject.Find("NetworkControl");
        Destroy(nc);
        SessionEndNotify pkg = new SessionEndNotify();
        UnityEngine.Debug.Log("��������ֹ����:" + pkg.Msg);
        Utils.MessageBox(System.IntPtr.Zero, "��������ֹ���ӣ�", "��ʾ", 0);
    }
}
