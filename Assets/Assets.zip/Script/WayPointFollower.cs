using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayPointFollower : MonoBehaviour
{
    [SerializeField] private GameObject[] waypoints;
    private int curIndex=0;

    [SerializeField] private float speed = 2f;

    // Update is called once per frame
    private void Update()
    {
        if (waypoints.Length == 0)
        {
            return;
        }

        // �Ƚ�������ά�����ľ���
        if (Vector2.Distance(waypoints[curIndex].transform.position, transform.position) < 0.1f)
        {
            //��ͷ�ˣ��л���һ��ǰ��Ŀ��
            curIndex  = (curIndex + 1)%waypoints.Length;
        }

        //�ƶ���ǰƽ̨
        // Time.deltaTime * speed��Ϊÿһ֡ǰ���ľ���
        transform.position = Vector2.MoveTowards(transform.position, waypoints[curIndex].transform.position, Time.deltaTime * speed);
    }
}
